import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA3gtNSvnbv7cr6dAmW6xn6uZhj8NSiwfw",
  authDomain: "hylarysbondafood.firebaseapp.com",
  projectId: "hylarysbondafood",
  storageBucket: "hylarysbondafood.firebasestorage.app",
  messagingSenderId: "299443634166",
  appId: "1:299443634166:web:f7dc6de5bbb219680491d7",
  measurementId: "G-LBVZ32E5D3"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Datos del dispositivo que se guardan con cada registro
export const info = () => ({
  dispositivo: navigator.userAgent, idioma: navigator.language,
  pantalla: screen.width + "x" + screen.height,
  zonaHoraria: Intl.DateTimeFormat().resolvedOptions().timeZone, url: location.href
});
// Cada visita queda en la colección "visitas"
export const guardarVisita = pagina => addDoc(collection(db, "visitas"),
  { pagina, referrer: document.referrer || null, ...info(), fecha: serverTimestamp() }).catch(() => {});
